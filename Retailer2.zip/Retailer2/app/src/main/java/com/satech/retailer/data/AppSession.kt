package com.satech.retailer.data

object AppSession {

    var testSession = " "
}